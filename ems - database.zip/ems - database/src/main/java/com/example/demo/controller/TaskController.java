package com.example.demo.controller;

import com.example.demo.entity.Task;
import com.example.demo.model.TaskCreateModel;
import com.example.demo.service.TaskCreationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/task")
@RequiredArgsConstructor

public class TaskController {

    private final TaskCreationService taskCreationService;

    @PostMapping("/create/{batchId}/{trainerId}")
    ResponseEntity<Task> createTask(@RequestBody TaskCreateModel task , @PathVariable Long batchId , @PathVariable Long trainerId){
        return taskCreationService.createTask(task , batchId , trainerId);
    }

}
