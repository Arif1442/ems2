package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import lombok.*;

import java.util.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table( name = "batch" )

public class Batch {

    @Id
    @GeneratedValue( strategy = GenerationType.IDENTITY )
    private Long batchId;

    private String batchName;
    @JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-MM-yyyy")
    private Date startDate;

    @OneToMany
    private Set<Trainee> trainees;

    @ManyToMany
    private Set<Trainer> trainers;

    @OneToMany
    private Set<Task> tasks;

}
