package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "trainee")

public class Trainee {

    @Id
    @GeneratedValue( strategy = GenerationType.IDENTITY )
    private Long traineeId;

    private String institute;
    private Double cgpa;

    @OneToOne
    @JoinColumn(name = "userId")
    private User user;

    @ManyToOne
    @JoinColumn(name = "batchId")
    private Batch batch;

    @OneToMany
    private Set<Submission> submissions;

}
