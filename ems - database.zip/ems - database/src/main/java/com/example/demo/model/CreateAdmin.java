package com.example.demo.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class CreateAdmin {

    private String designation;
    private Long yearOfExperience;
    private String email;
    private String password;
    private String role;
    private String fullName;
    private String address;
//    private File profilePic;

}
