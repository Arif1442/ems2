package com.example.demo.model;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor

// No need to use @Builder in these Model/DTO classes. As we don't build objects of these class in further steps.
// Even all other lombok annotations are redundant here. As we get from the request and use just one object.
public class TaskEvaluationModel {

    private Double codingEquipment;
    private Double codeOutput;
    private Double codeQuality;
    private Double codeDemonstration;
    private Double codeUnderstanding;

}
