package com.example.demo.service;

import com.example.demo.entity.*;
import com.example.demo.model.TaskSubmissionModel;
import com.example.demo.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor

public class SubmissionService {

    private final SubmissionRepository submissionRepo;
    private final TaskRepository taskRepo;
    private final TraineeRepository traineeRepo;

    public ResponseEntity<Submission> createSubmission(TaskSubmissionModel taskSubmissionModel, Long taskId , Long traineeId){

        Trainee whichTrainee = traineeRepo.findById(traineeId).orElseThrow();
        Task whichTask = taskRepo.findById(taskId).orElseThrow();

        Submission newSubmission = Submission.builder()
                .comment(taskSubmissionModel.getComment())
                .dateAndTime(taskSubmissionModel.getDateAndTime())
                .trainee(whichTrainee)
                .task(whichTask)
                .build();
        Submission savedSubmission = submissionRepo.save(newSubmission);

        Set<Submission> submissions = whichTrainee.getSubmissions();
        submissions.add(newSubmission);
        whichTrainee.setSubmissions(submissions);
        traineeRepo.save(whichTrainee);

        return new ResponseEntity<>(savedSubmission , HttpStatus.CREATED);
    }

    public ResponseEntity<List<Submission>> viewAllSubmissions() {

        return new ResponseEntity<>( submissionRepo.findAll() , HttpStatus.OK);

    }

    public ResponseEntity<Submission> findSubmissionBySubmissionId(Long submissionId) {

        return new ResponseEntity<>( submissionRepo.findById(submissionId).orElseThrow() , HttpStatus.OK);

    }
}
