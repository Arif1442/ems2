package com.example.demo.service;

import com.example.demo.entity.*;
import com.example.demo.repository.*;
import com.example.demo.model.*;
import lombok.*;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor

public class TaskCreationService {

    private final TaskRepository taskRepo;
    private final BatchRepository batchRepo;
    private final TrainerRepository trainerRepo;

    public ResponseEntity<Task> createTask(TaskCreateModel task , Long batchId , Long trainerId){

        Task newTask = Task.builder()
                .taskTitle(task.getTaskTitle())
                .taskType(task.getTaskType())
                .taskDate(task.getTaskDate())
                .batch( batchRepo.findById(batchId).orElseThrow() )
                .trainer( trainerRepo.findById(trainerId).orElseThrow())
                .build();
        Task savedTask = taskRepo.save(newTask);

        Batch updatedBatch = batchRepo.findById(batchId).orElseThrow();
        Set<Task> tasks = updatedBatch.getTasks();
        tasks.add(newTask);
        updatedBatch.setTasks(tasks);
        batchRepo.save(updatedBatch);

        return new ResponseEntity<>(savedTask , HttpStatus.CREATED);

    }

    public ResponseEntity<List<Task>> viewAllTasks(){

        return new ResponseEntity<>( taskRepo.findAll() , HttpStatus.OK);

    }

    public ResponseEntity<Task> findTaskByTaskId(Long taskId){

        return new ResponseEntity<>( taskRepo.findById(taskId).orElseThrow() , HttpStatus.OK);

    }

}
