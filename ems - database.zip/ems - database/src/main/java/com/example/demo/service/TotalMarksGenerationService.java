package com.example.demo.service;

import com.example.demo.entity.*;
import com.example.demo.repository.*;
import lombok.*;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor

public class TotalMarksGenerationService {

    private final BatchRepository batchRepo;
    private final TaskEvaluateRepository taskEvaluateRepo;
    private final ManagerEvaluationRepository managerEvaluationRepo;
    private final HREvaluationRepository hrEvaluationRepo;
    private final TotalMarksRepository finalMarksRepo;

    public ResponseEntity<List<TotalMarks>> createFinalMarksForWholeBatch(Long batchId){

        Batch whichBatch = batchRepo.findById(batchId).orElseThrow();
        Set<Trainee> trainees = whichBatch.getTrainees();
        List<TotalMarks> savedTotalMarks = new ArrayList<>();

        for( Trainee tempTrainee : trainees ){

            List<TaskEvaluation> taskEvaluation = taskEvaluateRepo.findByTrainee(tempTrainee);
            ManagerEvaluation managerEvaluation = managerEvaluationRepo.findByTrainee(tempTrainee);
            HREvaluation hrEvaluation = hrEvaluationRepo.findByTrainee(tempTrainee);

            Double dt = 0.0 , mp = 0.0 , mt = 0.0 , fp = 0.0;

            for( TaskEvaluation regularTasks : taskEvaluation){

                if( regularTasks.getType().equalsIgnoreCase("DailyTask") )
                    dt += regularTasks.getTotalMarks();
                else if (regularTasks.getType().equalsIgnoreCase("MiniProject"))
                    mp += regularTasks.getTotalMarks();
                else if (regularTasks.getType().equalsIgnoreCase("MidTermProject"))
                    mt += regularTasks.getTotalMarks();
                else
                    fp += regularTasks.getTotalMarks();

            }

            TotalMarks newTotalMarks = TotalMarks.builder()
                    .dailyTask(dt)
                    .midTerm(mt)
                    .miniProject(mp)
                    .finalProject(fp)
                    .managerEvaluation(managerEvaluation.getTotalMarks())
                    .hrEvaluation(hrEvaluation.getTotalMarks())
                    .totalMarks( // Need to know 'koto marks er moddhe koto paise. then oitare convert korte hobe ekta round number e, then percentage with the total marks.
                                (dt * 0.06) +
                                (mp * 0.06) +
                                (mt * 0.10) +
                                (fp * 0.25) +
                                (managerEvaluation.getTotalMarks() * 0.20) +
                                (hrEvaluation.getTotalMarks() * 0.33)
                    )
                    .trainee(tempTrainee)
                    .build();
            savedTotalMarks.add( finalMarksRepo.save(newTotalMarks) );
        }

        return new ResponseEntity<>(savedTotalMarks, HttpStatus.CREATED );
    }
}
